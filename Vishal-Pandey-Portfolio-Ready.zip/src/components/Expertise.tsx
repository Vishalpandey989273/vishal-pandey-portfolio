import React from "react";
import '@fortawesome/free-regular-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faReact, faPython, faLinux } from '@fortawesome/free-brands-svg-icons';
import Chip from '@mui/material/Chip';
import '../assets/styles/Expertise.scss';

const webSkills = ["HTML5","CSS3","JavaScript","React","Node.js","Express.js","REST API","Responsive Design"];
const securitySkills = ["Linux","Networking","TCP/IP","OWASP","Nmap","Wireshark","Burp Suite","Bash"];
const programmingSkills = ["Python","C","C++","Java","Git","GitHub","VS Code","SQL"];

function Expertise() {
  return (
    <div className="container" id="expertise">
      <div className="skills-container">
        <h1>Skills & Expertise</h1>
        <div className="skills-grid">
          <div className="skill">
            <FontAwesomeIcon icon={faReact} size="3x"/>
            <h3>Web Development</h3>
            <p>I build responsive websites and web applications using modern frontend and backend technologies.</p>
            <div className="flex-chips"><span className="chip-title">Tech stack:</span>
              {webSkills.map((label,index)=><Chip key={index} className="chip" label={label}/>)}
            </div>
          </div>
          <div className="skill">
            <FontAwesomeIcon icon={faLinux} size="3x"/>
            <h3>Cybersecurity</h3>
            <p>Interested in practical cybersecurity, Linux, networking, web security and security testing fundamentals.</p>
            <div className="flex-chips"><span className="chip-title">Skills:</span>
              {securitySkills.map((label,index)=><Chip key={index} className="chip" label={label}/>)}
            </div>
          </div>
          <div className="skill">
            <FontAwesomeIcon icon={faPython} size="3x"/>
            <h3>Programming & Tools</h3>
            <p>Comfortable with programming fundamentals, version control and building small automation and software projects.</p>
            <div className="flex-chips"><span className="chip-title">Tools:</span>
              {programmingSkills.map((label,index)=><Chip key={index} className="chip" label={label}/>)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Expertise;
