import React from "react";
import GitHubIcon from '@mui/icons-material/GitHub';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import '../assets/styles/Main.scss';

function Main() {
  return (
    <div className="container">
      <div className="about-section">
        <div className="image-wrapper">
          <img src="/profile.jpg" alt="Vishal Pandey" />
        </div>
        <div className="content">
          <div className="social_icons">
            <a href="https://github.com/" target="_blank" rel="noreferrer"><GitHubIcon/></a>
            <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer"><LinkedInIcon/></a>
          </div>
          <h1>Vishal Pandey</h1>
          <p>Web Developer | Cybersecurity Enthusiast</p>

          <div className="mobile_social_icons">
            <a href="https://github.com/" target="_blank" rel="noreferrer"><GitHubIcon/></a>
            <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer"><LinkedInIcon/></a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Main;
