import React from "react";
import mock01 from '../assets/images/mock01.png';
import mock02 from '../assets/images/mock02.png';
import mock03 from '../assets/images/mock03.png';
import mock04 from '../assets/images/mock04.png';
import mock05 from '../assets/images/mock05.png';
import '../assets/styles/Project.scss';

const projects = [
  ["Vishal Transport Website","A transport and tempo booking website concept with service information, booking flow and customer contact sections.","mock01"],
  ["Support Ticket Triage Copilot","A support workflow project concept for organizing incoming tickets and helping prioritize customer issues.","mock02"],
  ["Password Strength Tester","A web security project that evaluates password strength using frontend validation and security-focused rules.","mock03"],
  ["Personal Portfolio","A responsive developer portfolio built with React and modern UI components.","mock04"],
  ["Cybersecurity Learning Lab","Hands-on practice covering Linux, networking, web security and security testing fundamentals.","mock05"]
];

const images:any = { mock01, mock02, mock03, mock04, mock05 };

function Project() {
  return (
    <div className="projects-container" id="projects">
      <h1>Personal Projects</h1>
      <div className="projects-grid">
        {projects.map(([title, description, image], index) => (
          <div className="project" key={index}>
            <a href="https://github.com/" target="_blank" rel="noreferrer">
              <img src={images[image]} className="zoom" alt={title} width="100%"/>
            </a>
            <a href="https://github.com/" target="_blank" rel="noreferrer"><h2>{title}</h2></a>
            <p>{description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Project;
